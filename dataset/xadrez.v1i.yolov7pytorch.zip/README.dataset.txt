# xadrez > 2023-04-01 7:46am
https://universe.roboflow.com/ic-jibvp/xadrez-7cumt

Provided by a Roboflow user
License: CC BY 4.0

